<?php 
		include("../conexion.php");

		$con=conectar();


		mysql_query("INSERT INTO Prestamos (Cod_Usuarios,Nombre,Apellido,Nom_libros,Fecha_Inicial,Fecha_Max,Fecha_Final,Cod_Libros) VALUES ('$_POST[Cod_Usuarios]','$_POST[Nombre]','$_POST[Apellido]','$_POST[Nom_libros]','$_POST[Fecha_Inicial]','$_POST[Fecha_Max]','$_POST[Fecha_Final]','$_POST[Cod_libros]')",$con);
 ?>