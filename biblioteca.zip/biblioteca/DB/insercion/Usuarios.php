<?php 
		include("../conexion.php");
		$con=conectar();
		mysql_query("INSERT INTO Usuarios (Cod_Usuarios,Nombre,Apellido,Direccion) VALUES ('$_POST[Cod_Usuarios]','$_POST[Nombre]','$_POST[Apellido]','$_POST[Direccion]')",$con);
 ?>