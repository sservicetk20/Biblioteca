<?php 
		include("../conexion.php");
		$con=conectar();
		mysql_query("INSERT INTO Autor (Autor,Nacionalidad,Fecha_publicacion) VALUES ('$_POST[Autor]','$_POST[Nacionalidad]','$_POST[Fecha_publicacion]')",$con);

 ?>