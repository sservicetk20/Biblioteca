<?php 
		include("../conexion.php");
		$con=conectar();
		mysql_query("INSERT INTO Libros (Cod_libros,Nom_libros,Genero,id_Autor,Editorial,Copias) VALUES ('$_POST[Cod_libros]','$_POST[Nom_libros]','$_POST[Genero]','$_POST[id_Autor]','$_POST[Editorial]','$_POST[Copias]')",$con);
 ?>