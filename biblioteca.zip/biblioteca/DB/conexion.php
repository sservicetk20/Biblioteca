<?php 
	function conectar(){
		$user="root";
		$pass="root";
		$server="localhost";//wwww.dominio.com
		$db="Biblioteca";
		$con=mysql_connect($server,$user,$pass) or die("entrar a conectarse a la base de datos".mysql_error());
		mysql_select_db($db,$con);

		return $con;
	}
 ?>