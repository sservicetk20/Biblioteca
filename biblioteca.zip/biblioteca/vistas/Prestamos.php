<!DOCTYPE html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>

  <title>Biblioteca</title>
<body>

<nav class="navbar navbar-inverse"><div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="../index.php">Home</a></li>
      <li><a href="Nuevo.php">Agregar</a></li>
      <li><a href="Prestamos.php">Prestamos</a></li> 
     <li><a href="Vistas.php">Consultas</a></li> 
    </ul>
  </div>

</nav>
<div class="text-center">
    <h1>Biblioteca</h1>
  </div>
 <div class="row">
  <div class="col-md-6 col-md-offset-3">
 <form class="form form-horizontal" name ="formulario" method="post" action="../DB/insercion/Prestamos.php ">

 <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Codigo de usuarios</label>
    <div class="col-lg-10">
     <select class="form-control" type="text"  id="sel1" name="Cod_Usuarios"/>
      <option>
        <?php  
            include("../DB/conexion.php");
            $con=conectar();
            $t ="SELECT Cod_Usuarios FROM Usuarios;";
            $result= mysql_query($t);

             while($res = mysql_fetch_array($result)){ 
              echo "<option>".$res[Cod_Usuarios]."</option>";
            } 
          ?>
      </option>
        </select>
    </div>
  </div>

  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Nombre</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Nombre"/>
    </div>
  </div>

  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Apellido</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Apellido"/>
    </div>
  </div>

  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Nombre del libro</label>
    <div class="col-lg-10">
     <select class="form-control" id="sel1" type="text" name="Nom_libros"/>
     <option>
     <?php 
      $t ="SELECT Nom_libros FROM Libros;";
      $result= mysql_query($t);

      while($res = mysql_fetch_array($result)){ 
        echo "<option>".$res[Nom_libros]."</option>";
      } 
    ?>
  </option>
       </select>
    </div>
  </div>

  <form class="form-horizontal" role="form">
    <div class="form-group">
      <label class="col-lg-2 control-label">codigo del libro</label>
        <div class="col-lg-10">
          <select class="form-control" type="text"  id="sel1" name="Cod_libros"/>
             <option>
          <?php
            $t ="SELECT Cod_libros FROM Libros;";
            $result= mysql_query($t);

             while($res = mysql_fetch_array($result)){ 
              echo "<option>".$res[Cod_libros]."</option>";
            } 
          ?>
             </option>
          </select>
      </div>
    </div>



  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Fecha de prestamo</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Fecha_Inicial"/>
    </div>
  </div>


   <form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="ejemplo_email_3" class="col-lg-2 control-label">Fecha de entrega</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Fecha_Final"/>
    </div>
  </div>


  <div class="col-md-6 col-md-offset-5">
	<input class="btn btn-success" type="submit" value="Almacenar" />
	<input class="btn btn-center btn-success" type="reset" value="Reset">

 </div>

 </form>
  </div>
</div>

</body>
</html>
