<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../css/estilo.css">
<head>
	<title>Biblioteca</title>
</head>
<body>
<nav class="navbar navbar-inverse">

</div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="../index.php">Home</a></li>
       <li><a href="Nuevo.php">Agregar</a></li>
      <li><a href="Prestamos.php">Prestamos</a></li> 
      <li><a href="Vistas.php">Consultas</a></li> 
    </ul>
  </div>

</nav>
<div class="text-center">
    <h1>Biblioteca</h1>
  </div>
 <div class="row">
  <div class="col-md-6 col-md-offset-3">
 <form class="form form-horizontal" name ="formulario" method="post" action="../DB/insercion/Libros.php">

 <form class="form-horizontal" role="form">
  <div class="form-group">
    <label class="col-lg-2 control-label">codigo de libros</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Cod_libros"/>
    </div>
  </div>
		
<form class="form-horizontal" role="form">
  <div class="form-group">
    <label  class="col-lg-2 control-label">Nombre de libros</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Nom_libros"/>
    </div>
  </div>

  <form class="form-horizontal" role="form">
    <div class="form-group">
    <label  class="col-lg-2 control-label">Genero</label>
    <div class="col-lg-10">
       <select class="form-control" id="sel1" type="text" name="Genero"/>
           <option>Novela</option>
           <option>Teatro</option>
           <option>Poesía</option>
           <option>Ensayo</option>
       </select>
    </div>
  </div>

  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label class="col-lg-2 control-label">codigo de autor</label>
    <div class="col-lg-10">
     <select class="form-control" id="sel1" type="text" name="id_Autor"/>
     <option>
     <?php include("../DB/conexion.php");
          $con=conectar();
            $t ="SELECT id_Autor FROM Autor;";
            $result= mysql_query($t);

      while($res = mysql_fetch_array($result)){ 
        echo "<option>".$res[id_Autor]."</option>";
    } 
  ?>
  </option>
       </select>
    </div>
  </div>

  <form class="form-horizontal" role="form">
  <div class="form-group">
    <label  class="col-lg-2 control-label">Editorial</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Editorial"/>
    </div>
  </div>


<form class="form-horizontal" role="form">
  <div class="form-group">
    <label  class="col-lg-2 control-label">Copias</label>
    <div class="col-lg-10">
     <input class="form-control" type="text" name="Copias"/>
    </div>
  </div>

  <div class="col-md-6 col-md-offset-5">
	<input class="btn btn-success" type="submit" value="Almacenar" />
	<input class="btn btn-center btn-success" type="reset" value="Reset">

 </div>

 </form>
  </div>
</div>

</body>
</html>
