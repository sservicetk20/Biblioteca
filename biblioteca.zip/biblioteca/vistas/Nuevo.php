<!DOCTYPE html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>

      <title>Biblioteca</title>
<body>

<nav class="navbar navbar-inverse"><div>
    <ul class="nav navbar-nav">
    <li class="active"><a href="../index.php">Home</a></li>
    <li><a href="Nuevo.php">Agregar</a></li> 
      <li><a href="Prestamos.php">Prestamos</a></li> 
      <li><a href="Vistas.php">Consultas</a></li> 
    </ul>
  </div>
</nav>

<div class="jumbotron">
  <h1 class="margin-jumbotron text-center biblioteca">Biblioteca de la universidad xyz</h1>
  <p class="margin-jumbotron text-center">
    Bienvenido en esta seccion podras agregar autores,libros y 
    usuarios haciendo click en cada uno de los botones 
    que indica la accion
  </p>
</div>

 <div class="text-center">
    <h1 class="color-azul">Modulo de Agregar</h1>
    <br>
  </div>

<div class="col-xs-4 center-block">
   <div class="thumbnail">
      <img src="../img/autor.png" class="img img-circle" alt="imagen">
      <div class="caption">
          <h3 class="text-center">Autores</h3>
              <p>Donec nec justo eget felis facilisis fermentum. 
               Aliquam porttitor mauris sit amet orci.</p>
          <p>
          <a href="Autor.php" class="btn btn-primary col-center-block">Autores</a> 
          </p>
      </div>
   </div>
 </div>

<div class="col-xs-4">
   <div class="thumbnail">
      <img src="../img/libros.png" class="img img-circle" alt="imagen">
      <div class="caption">
          <h3 class="text-center up">Libros</h3>
              <p>Donec nec justo eget felis facilisis fermentum. 
               Aliquam porttitor mauris sit amet orci.</p>
          <p>
          <a href="Libro.php" class="btn btn-primary col-center-block">Libros</a> 
          </p>
      </div>
   </div>
 </div>



<div class="col-xs-4">
   <div class="thumbnail">
      <img src="../img/usuarios.png" class="img img-circle" alt="imagen">
      <div class="caption">
          <h3 class="text-center">Usuarios</h3>
              <p>Donec nec justo eget felis facilisis fermentum. 
               Aliquam porttitor mauris sit amet orci.</p>
          <p>
          <a href="Usuarios.php" class="btn btn-primary col-center-block">Usuarios</a> 
          </p>
      </div>
   </div>
 </div>


</body>
</html>
