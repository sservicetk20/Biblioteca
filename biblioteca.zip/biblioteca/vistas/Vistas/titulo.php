<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
<head>
  <title>Biblioteca</title>
</head>
<body>
<nav class="navbar navbar-inverse">

</div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="../../index.php">Home</a></li>
       <li><a href="../Nuevo.php">Agregar</a></li>
      <li><a href="../Prestamos.php">Prestamos</a></li>
      <li><a href="../Vistas.php">Consultas</a></li> 
    </ul>
  </div>

</nav>
<div class="text-center">
    <h1>Biblioteca</h1>
  </div>

 <div class="row">
  <div class="col-md-6 col-md-offset-3">
 <form class="form form-horizontal" name ="formulario" method="post" action="../DB/insercion/insercion.php">

<div class="text-center">
    <h1>libros</h1>
  </div>
  <a href="../Vistas.php" class="label label-info">Consultas</a>
<a href="titulo.php" class="label label-info">Busqueda por Titulos</a>
<a href="Con_prestamos.php" class="label label-info">Prestamos</a>
<a href="usuarios.php" class="label label-info">Prestamos por usuarios</a>
<?php 
  include("../../DB/conexion.php");
  $con=conectar();
  // Consulta Paso 1: Ejecutar Query
  $t ="SELECT id_Libros,Cod_libros,Nom_libros,Genero,id_Autor,Copias FROM Libros;";
    $result= mysql_query($t);
      echo "<table class='table table-striped'><tr><td>Titulos</td><td>Cantidad disponibles</td></tr><tr>";
        while($res = mysql_fetch_assoc($result))
        {
            echo "<table class='table table-striped text-right'><tr><td>";
            echo $res[Nom_libros]."</td><td>";
            echo $res[Copias]."</td><td>";
            echo "</tr></table>";
        }
 ?>
</table>

 </form>
  </div>
</div>

</body>
</html>
